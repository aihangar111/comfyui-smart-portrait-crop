#!/usr/bin/env python3
"""
Smart Portrait Crop - standalone version (no ComfyUI needed).

Turns a landscape video into a 9:16 vertical video (or a portrait video into 16:9)
with a smoothed virtual camera that follows the action.

  python portrait_crop.py my_video.mp4
  python portrait_crop.py my_video.mp4 --fit blur
  python portrait_crop.py my_video.mp4 --tracking aircraft
  python portrait_crop.py my_video.mp4 --tracking manual --keyframes "0:0.35, 240:0.5, 600:0.65"

The tracking logic is a port of the ComfyUI "Smart Portrait Crop (9:16)" node,
without the YOLO detector modes. Needs: numpy, opencv-python-headless, imageio-ffmpeg.
"""
import argparse
import os
import subprocess
import sys
import time

import cv2
import numpy as np

THUMB_W = 192  # tracking runs on small thumbnails, which is what makes it fast


# --------------------------------------------------------------------------- helpers
def ffmpeg_exe():
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        return "ffmpeg"


def progress(label, i, n):
    if n > 0 and (i % 15 == 0 or i == n):
        sys.stdout.write(f"\r{label}: {100.0 * i / n:5.1f}%")
        sys.stdout.flush()
        if i == n:
            sys.stdout.write("\n")


def box(a, k):
    return cv2.blur(a, (k, k), borderType=cv2.BORDER_REPLICATE)


def parse_keyframes(text):
    """'0:0.3, 120:0.5, 300:0.7' -> sorted [(frame, x)]  (x: 0 = left/top edge, 1 = right/bottom edge)."""
    pts = []
    for tok in text.replace("\n", ",").replace(";", ",").split(","):
        tok = tok.strip()
        if ":" in tok:
            try:
                f, x = tok.split(":", 1)
                pts.append((float(f), min(1.0, max(0.0, float(x)))))
            except ValueError:
                pass
    pts.sort()
    return pts or [(0.0, 0.5)]


def _median(x, k):
    if k <= 1 or len(x) < 3:
        return x
    pad = k // 2
    xp = np.pad(x, (pad, pad), mode="edge")
    return np.array([np.median(xp[i:i + k]) for i in range(len(x))])


def _ema(x, a):
    y = np.empty_like(x)
    y[0] = x[0]
    for i in range(1, len(x)):
        y[i] = a * x[i] + (1 - a) * y[i - 1]
    return y


def smooth_segment(f, deadzone, smoothing):
    """median -> dead-zone hold -> zero-lag forward/backward smoothing."""
    f = _median(f, 5)
    c = f[0]
    held = np.empty_like(f)
    for i, v in enumerate(f):
        if v > c + deadzone:
            c = v - deadzone
        elif v < c - deadzone:
            c = v + deadzone
        held[i] = c
    a = max(0.02, 1.0 - 0.97 * smoothing)
    fwd = _ema(held, a)
    return _ema(fwd[::-1], a)[::-1]


# --------------------------------------------------------------------------- pass 1: thumbnails
def read_thumbs(path):
    cap = cv2.VideoCapture(path)
    if not cap.isOpened():
        sys.exit(f"Could not open the video: {path}")
    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    thumbs, W, H, i = [], 0, 0, 0
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        if i == 0:
            H, W = frame.shape[:2]
            th = max(8, int(round(H * THUMB_W / W)))
        small = cv2.resize(frame, (THUMB_W, th), interpolation=cv2.INTER_AREA)
        thumbs.append(cv2.cvtColor(small, cv2.COLOR_BGR2GRAY))
        i += 1
        progress("Analyzing", i, total)
    cap.release()
    if not thumbs:
        sys.exit("The video has no readable frames.")
    return np.stack(thumbs), W, H, fps


# --------------------------------------------------------------------------- tracking
def static_map(thumbs):
    """Parts of a fixed-camera shot that never change (window frame, cockpit) get down-weighted."""
    n = len(thumbs)
    s = np.zeros(thumbs.shape[1:], np.float64)
    s2 = np.zeros_like(s)
    for a in range(0, n, 256):
        c = thumbs[a:a + 256].astype(np.float64) / 255.0
        s += c.sum(0)
        s2 += (c * c).sum(0)
    sd = np.sqrt(np.maximum(s2 / n - (s / n) ** 2, 0))
    return np.clip(sd / (sd.max() + 1e-6), 0, 1) ** 0.5


def analyze(thumbs, track_x, mode, a):
    """Returns per-frame position profiles along the free axis and a scene-cut score per frame."""
    n, th, tw = thumbs.shape
    axis_len = tw if track_x else th
    pos = np.linspace(0, 1, axis_len, dtype=np.float32)
    prior = a.center_bias * np.exp(-((pos - 0.5) ** 2) / (2 * 0.22 ** 2))
    prior = prior[None, :] if track_x else prior[:, None]
    live = static_map(thumbs) if (mode == "aircraft" and a.ignore_static > 0 and n > 1) else None

    prof = np.empty((n, axis_len), np.float32)
    cut_score = np.zeros(n, np.float32)
    prev_g = prev_h = None
    for i in range(n):
        g = thumbs[i].astype(np.float32) / 255.0
        h, _ = np.histogram(g, bins=32, range=(0.0, 1.0))
        h = h / (h.sum() + 1e-6)
        if prev_g is None:
            prev_g, prev_h = g, h
        cut_score[i] = 0.5 * np.abs(h - prev_h).sum()

        motion = box(np.abs(g - prev_g), 5)
        gx = np.pad(np.abs(g[:, 1:] - g[:, :-1]), ((0, 0), (0, 1)))
        gy = np.pad(np.abs(g[1:, :] - g[:-1, :]), ((0, 1), (0, 0)))
        detail = box(gx + gy, 7)
        motion = motion / (motion.max() + 1e-6)
        detail = detail / (detail.max() + 1e-6)

        if mode == "aircraft":
            # Aircraft stand out from smooth sky: local contrast against a heavy blur of the frame.
            bg = cv2.blur(g, (51, 51), borderType=cv2.BORDER_REPLICATE)
            contrast = box(np.abs(g - bg), 3)
            contrast = contrast / (contrast.max() + 1e-6)
            if live is not None:
                contrast = contrast * ((1 - a.ignore_static) + a.ignore_static * live)
            score = contrast ** 2 + 0.3 * a.detail_weight * detail + 0.25 * a.motion_weight * motion + 1e-4
        else:
            score = a.motion_weight * motion + a.detail_weight * detail
            score = score + prior * score.mean() * 2 + 1e-4

        p = score.sum(0) if track_x else score.sum(1)
        prof[i] = p ** 2
        prev_g, prev_h = g, h
    return prof, cut_score, pos


def centers_from_profiles(prof, pos, cuts, mode):
    n, axis_len = prof.shape
    if mode != "aircraft":
        return (prof * pos[None, :]).sum(1) / (prof.sum(1) + 1e-9)
    # Stick to one object: only look near where it was, take the centroid of the strongest peak.
    out, last = [], None
    for i in range(n):
        p = prof[i].copy()
        if cuts[i]:
            last = None
        if last is not None:
            p = p * (0.1 + np.exp(-((pos - last) ** 2) / (2 * 0.18 ** 2)))
        pk = int(np.argmax(p))
        win = max(2, int(0.30 * axis_len))
        lo_i, hi_i = max(0, pk - win), min(axis_len, pk + win + 1)
        seg = p[lo_i:hi_i]
        seg = seg * (seg > 0.2 * seg.max())
        c = float((seg * pos[lo_i:hi_i]).sum() / (seg.sum() + 1e-9))
        out.append(c)
        last = c
    return np.array(out)


def plan_camera(thumbs, W, H, out_w, out_h, a):
    n = len(thumbs)
    aspect = out_w / out_h
    track_x = (W / H) > aspect
    if track_x:
        free, size_free = W, H * aspect
    else:
        free, size_free = H, W / aspect

    mode = a.tracking
    cuts = np.zeros(n, bool)
    cuts[0] = True
    if mode in ("auto", "aircraft"):
        prof, cut_score, pos = analyze(thumbs, track_x, mode, a)
        cuts = cut_score > a.cut_sensitivity
        cuts[0] = True
        raw = centers_from_profiles(prof, pos, cuts, mode) * free
    elif mode == "manual":
        kp = parse_keyframes(a.keyframes)
        raw = np.interp(np.arange(n), [k[0] for k in kp], [k[1] for k in kp]) * free
    else:  # center
        raw = np.full(n, free / 2.0)
    raw = raw + a.x_offset * free

    if mode == "manual":
        cam = _ema(_ema(raw, 0.3)[::-1], 0.3)[::-1]
    elif mode == "center":
        cam = raw.copy()
    else:
        cam = np.empty(n)
        starts = [i for i in range(n) if cuts[i]] + [n]
        for s, e in zip(starts[:-1], starts[1:]):
            cam[s:e] = smooth_segment(raw[s:e], a.deadzone * size_free, a.smoothing)

    lo, hi = size_free / 2, free - size_free / 2
    cam = np.clip(cam, lo, hi)
    g_lo, g_hi = sorted((a.min_x * free, a.max_x * free))
    cam = np.clip(cam, max(lo, g_lo), max(max(lo, g_lo), min(hi, g_hi)))
    return cam, track_x, size_free, int(cuts.sum())


# --------------------------------------------------------------------------- pass 2: render
def window_matrix(c, W, H, out_w, out_h, track_x, size_free, scale_div=1):
    """Affine matrix mapping the crop window (centred at c) onto the output frame, sub-pixel exact."""
    if track_x:
        s = out_h / H
        x0, y0 = c - size_free / 2, 0.0
    else:
        s = out_w / W
        x0, y0 = 0.0, c - size_free / 2
    s /= scale_div
    return np.array([[s, 0, s * (0.5 - x0) - 0.5],
                     [0, s, s * (0.5 - y0) - 0.5]], np.float64)


def render_frame(frame, c, W, H, out_w, out_h, fit, track_x, size_free):
    if fit == "crop":
        M = window_matrix(c, W, H, out_w, out_h, track_x, size_free)
        return cv2.warpAffine(frame, M, (out_w, out_h), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE)
    # blurred background: dimmed blurred copy of the camera window behind the whole frame
    bw, bh = max(8, out_w // 8), max(8, out_h // 8)
    M = window_matrix(c, W, H, out_w, out_h, track_x, size_free, scale_div=8)
    bg = cv2.warpAffine(frame, M, (bw, bh), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
    bg = cv2.GaussianBlur(bg, (0, 0), 1.0)
    bg = cv2.resize(bg, (out_w, out_h), interpolation=cv2.INTER_LINEAR)
    bg = cv2.convertScaleAbs(bg, alpha=0.55)
    sc = min(out_w / W, out_h / H)
    fw, fh = min(out_w, int(round(W * sc))), min(out_h, int(round(H * sc)))
    interp = cv2.INTER_AREA if sc < 1 else cv2.INTER_CUBIC
    fg = cv2.resize(frame, (fw, fh), interpolation=interp)
    top, left = (out_h - fh) // 2, (out_w - fw) // 2
    bg[top:top + fh, left:left + fw] = fg
    return bg


def render(path, out_path, cam, W, H, out_w, out_h, fps, fit, track_x, size_free, crf):
    cmd = [ffmpeg_exe(), "-y", "-loglevel", "error",
           "-f", "rawvideo", "-pix_fmt", "bgr24", "-s", f"{out_w}x{out_h}", "-r", f"{fps:.6f}", "-i", "-",
           "-i", path, "-map", "0:v:0", "-map", "1:a:0?",
           "-c:v", "libx264", "-preset", "veryfast", "-crf", str(crf), "-pix_fmt", "yuv420p",
           "-c:a", "aac", "-b:a", "192k", "-shortest", "-movflags", "+faststart", out_path]
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    cap = cv2.VideoCapture(path)
    n = len(cam)
    try:
        for i in range(n):
            ok, frame = cap.read()
            if not ok:
                break
            out = render_frame(frame, cam[i], W, H, out_w, out_h, fit, track_x, size_free)
            proc.stdin.write(out.tobytes())
            progress("Rendering", i + 1, n)
    except BrokenPipeError:
        pass
    finally:
        cap.release()
        try:
            proc.stdin.close()
        except Exception:
            pass
        code = proc.wait()
    if code != 0:
        sys.exit("ffmpeg failed while writing the video (see the message above).")


# --------------------------------------------------------------------------- main
def pick_output(path, suffix):
    base = os.path.splitext(path)[0] + suffix
    out, k = base + ".mp4", 2
    while os.path.exists(out):
        out = f"{base}_{k}.mp4"
        k += 1
    return out


def main():
    p = argparse.ArgumentParser(description="Reframe a video to 9:16 (or 16:9) with a smoothed virtual camera.")
    p.add_argument("input")
    p.add_argument("-o", "--output")
    p.add_argument("--to", choices=["auto", "portrait", "landscape"], default="auto",
                   help="auto: landscape video -> 9:16, portrait video -> 16:9")
    p.add_argument("--fit", choices=["crop", "blur"], default="crop",
                   help="crop: fill the frame. blur: show the whole picture over a dimmed, blurred copy")
    p.add_argument("--tracking", choices=["auto", "aircraft", "center", "manual"], default="auto")
    p.add_argument("--keyframes", default="0:0.5", help="manual mode, e.g. \"0:0.35, 240:0.5, 600:0.65\"")
    p.add_argument("--short-side", type=int, default=1080, help="1080 gives 1080x1920 or 1920x1080")
    p.add_argument("--smoothing", type=float, default=0.85)
    p.add_argument("--deadzone", type=float, default=0.12)
    p.add_argument("--x-offset", type=float, default=0.0)
    p.add_argument("--min-x", type=float, default=0.0)
    p.add_argument("--max-x", type=float, default=1.0)
    p.add_argument("--cut-sensitivity", type=float, default=0.35)
    p.add_argument("--ignore-static", type=float, default=0.8)
    p.add_argument("--motion-weight", type=float, default=1.0)
    p.add_argument("--detail-weight", type=float, default=0.6)
    p.add_argument("--center-bias", type=float, default=0.25)
    p.add_argument("--crf", type=int, default=18)
    a = p.parse_args()

    if not os.path.isfile(a.input):
        sys.exit(f"File not found: {a.input}")
    t0 = time.time()
    thumbs, W, H, fps = read_thumbs(a.input)

    to = a.to if a.to != "auto" else ("portrait" if W >= H else "landscape")
    short = max(64, int(a.short_side) // 2 * 2)
    long_ = int(round(short * 16 / 9 / 2)) * 2
    out_w, out_h = (short, long_) if to == "portrait" else (long_, short)
    out_path = a.output or pick_output(a.input, "_9x16" if to == "portrait" else "_16x9")

    print(f"Source {W}x{H} @ {fps:.2f} fps, {len(thumbs)} frames -> {out_w}x{out_h}, "
          f"{'crop to fill' if a.fit == 'crop' else 'blurred background'}, tracking: {a.tracking}")
    cam, track_x, size_free, cuts = plan_camera(thumbs, W, H, out_w, out_h, a)
    free = W if track_x else H
    print(f"Scene cuts found: {cuts} | camera range {cam.min() / free:.2f}-{cam.max() / free:.2f} "
          f"({'left-right' if track_x else 'up-down'})")
    render(a.input, out_path, cam, W, H, out_w, out_h, fps, a.fit, track_x, size_free, a.crf)
    print(f"Done in {time.time() - t0:.0f}s: {out_path}")


if __name__ == "__main__":
    main()
