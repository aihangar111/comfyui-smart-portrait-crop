@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Smart Portrait Crop

rem ---------- find Python 3.9 or newer ----------
set "PY="
for %%C in ("py -3" "python") do (
  if not defined PY (
    %%~C -c "import sys; sys.exit(0 if sys.version_info >= (3,9) else 1)" >nul 2>nul && set "PY=%%~C"
  )
)
if not defined PY (
  echo Python 3.9 or newer was not found.
  echo.
  echo Please install it from https://www.python.org/downloads/
  echo During install, tick "Add python.exe to PATH". Then run this again.
  echo.
  pause
  exit /b 1
)

rem ---------- one-time setup ----------
set "VENV=%~dp0.venv"
if not exist "%VENV%\Scripts\python.exe" (
  echo First-time setup: this takes a minute or two and needs internet.
  %PY% -m venv "%VENV%"
  if errorlevel 1 goto :setup_failed
)
"%VENV%\Scripts\python.exe" -c "import numpy, cv2, imageio_ffmpeg" >nul 2>nul
if errorlevel 1 (
  echo Installing what the tool needs...
  "%VENV%\Scripts\python.exe" -m pip install --disable-pip-version-check -r "%~dp0requirements.txt"
  if errorlevel 1 goto :setup_failed
)

rem ---------- choices ----------
set "USEARGS="
if not "%~1"=="" set "USEARGS=1"

:choices
echo.
echo ============================================================
echo   Smart Portrait Crop
echo   Landscape video -^> vertical 9:16     Vertical video -^> 16:9
echo ============================================================
echo.
echo  How should the picture fit?
echo    [C] Crop to fill the screen (the camera follows the action)
echo    [B] Keep the whole picture over a blurred background
set "FIT=crop"
choice /c CB /n /m "Press C or B: "
if errorlevel 2 set "FIT=blur"

echo.
echo  What should the camera follow?
echo    [A] Automatic (motion and detail, good for most videos)
echo    [P] Aircraft or one small object against sky
echo    [M] Nothing, just keep the middle of the picture
set "TRK=auto"
choice /c APM /n /m "Press A, P or M: "
if errorlevel 2 set "TRK=aircraft"
if errorlevel 3 set "TRK=center"

rem ---------- the video(s) ----------
:get_video
if not defined USEARGS goto :prompt_file
set "USEARGS="
for %%F in (%*) do call :process "%%~F"
goto :again

:prompt_file
echo.
echo Drag your video file into this window, then press Enter.
set "IN="
set /p "IN=> "
if not defined IN (
  echo No file given.
  goto :again
)
set "IN=%IN:"=%"
call :process "%IN%"

:again
echo.
echo  Done. Process another video?
echo    [S] Yes, same settings
echo    [N] Yes, choose new settings
echo    [Q] Quit
choice /c SNQ /n /m "Press S, N or Q: "
if errorlevel 3 exit /b 0
if errorlevel 2 goto :choices
goto :get_video

:process
echo.
echo ------------------------------------------------------------
echo Processing: %~1
"%VENV%\Scripts\python.exe" "%~dp0portrait_crop.py" "%~1" --fit %FIT% --tracking %TRK%
if errorlevel 1 (
  echo.
  echo Something went wrong with this file. See the message above.
) else (
  echo.
  echo Saved next to the original.
)
exit /b 0

:setup_failed
echo.
echo Setup did not finish. Check your internet connection and try again.
echo If it keeps failing, delete the ".venv" folder here and run this again.
pause
exit /b 1
