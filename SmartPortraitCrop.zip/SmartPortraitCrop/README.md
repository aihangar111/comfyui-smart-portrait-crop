# Smart Portrait Crop - standalone (no ComfyUI needed)

Turns a landscape video into a vertical 9:16 video (1080x1920) with a camera that follows the action.
A vertical video becomes 16:9 (1920x1080). The direction is chosen automatically.

## Use it (Windows)

1. Install **Python 3.9 or newer** from python.org if you don't have it. Tick "Add python.exe to PATH".
2. Double-click `SmartPortraitCrop.bat`. The first run downloads what it needs (a minute or two, internet required).
3. Choose **Crop** or **Blurred background**, choose what the camera follows, then drag your video into the window and press Enter.
   You can also drag video files straight onto `SmartPortraitCrop.bat`.
4. The result is saved next to your original, named `..._9x16.mp4` or `..._16x9.mp4`. Original audio is kept.
5. Afterwards you can process another video with the same settings, pick new settings, or quit.

## Choices

- **Crop to fill:** fills the whole frame and slides left and right (or up and down) to follow the subject.
- **Blurred background:** shows the whole picture over a dimmed, blurred copy, so nothing is cut off.
- **Camera follow:** *Automatic* follows motion and detail. *Aircraft* is for a small object against sky. *Middle* keeps the center.

## Command line (advanced)

```
.venv\Scripts\python.exe portrait_crop.py my_video.mp4 --fit blur --tracking aircraft
.venv\Scripts\python.exe portrait_crop.py my_video.mp4 --tracking manual --keyframes "0:0.35, 240:0.5, 600:0.65"
```

Useful options: `--to portrait|landscape`, `--short-side 1080`, `--smoothing 0.85`, `--deadzone 0.12`,
`--x-offset 0.0`, `--min-x 0 --max-x 1`, `-o output.mp4`. Run with `--help` for all of them.
In manual mode, the keyframes are `frame:position` pairs from 0 (left/top) to 1 (right/bottom).

## Notes

- This version has no AI detector (no YOLO), so it follows motion and detail, not "airplane" or "person".
  The ComfyUI node has the detector modes.
- Auto tracking can be fooled by clutter or a subject that stops moving. `manual` is the most dependable.
- Videos with no sound work fine. The output simply has no sound.
